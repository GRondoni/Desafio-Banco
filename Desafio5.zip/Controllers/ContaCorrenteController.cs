using BancoApi.Application.DTOs;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using BancoApi.Application.Commands;
using BancoApi.Application.Queries;

namespace BancoApi.Controllers
{
    [ApiController]
    [Route("api/contacorrente")]
    public class ContaCorrenteController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ContaCorrenteController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("{id}/movimentar")]
        public async Task<IActionResult> Movimentar(string id, [FromBody] MovimentarContaCommand command)
        {
            command.IdContaCorrente = id;
            var result = await _mediator.Send(command);
            return result;
        }

        [HttpGet("{id}/saldo")]
        public async Task<IActionResult> ObterSaldo(string id)
        {
            var result = await _mediator.Send(new ObterSaldoQuery { IdContaCorrente = id });
            return Ok(result);
        }
    }
}