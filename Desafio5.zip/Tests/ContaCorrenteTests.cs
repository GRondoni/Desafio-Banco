using BancoApi.Application.Commands;
using BancoApi.Application.Handlers;
using BancoApi.Domain;
using MediatR;
using NSubstitute;
using Xunit;

namespace BancoApi.Tests
{
    public class ContaCorrenteTests
    {
        [Fact]
        public async Task Credito_Deve_Aumentar_Saldo()
        {
            var conta = new ContaCorrente();
            var handler = new MovimentarContaHandler(conta);
            var result = await handler.Handle(new MovimentarContaCommand("credito", 100), default);
            Assert.Equal(100, conta.Saldo);
        }

        [Fact]
        public async Task Debito_Com_Saldo_Suficiente_Deve_Diminuir_Saldo()
        {
            var conta = new ContaCorrente();
            conta.Creditar(150);
            var handler = new MovimentarContaHandler(conta);
            var result = await handler.Handle(new MovimentarContaCommand("debito", 50), default);
            Assert.Equal(100, conta.Saldo);
        }

        [Fact]
        public async Task Debito_Com_Saldo_Insuficiente_Deve_Lancar_Excecao()
        {
            var conta = new ContaCorrente();
            var handler = new MovimentarContaHandler(conta);

            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                handler.Handle(new MovimentarContaCommand("debito", 50), default)
            );
        }

        [Fact]
        public async Task Valor_Negativo_Deve_Ser_Rejeitado_No_Controller()
        {
            var controller = new BancoApi.Controllers.ContaCorrenteController(
                Substitute.For<IMediator>());

            var resultado = controller.MovimentarConta(new BancoApi.Application.DTOs.MovimentacaoRequest
            {
                Tipo = "credito",
                Valor = -10
            });

            Assert.IsType<Microsoft.AspNetCore.Mvc.BadRequestObjectResult>(resultado);
        }
    }
}