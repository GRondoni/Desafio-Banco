namespace BancoApi.Application.DTOs
{
    public class MovimentacaoRequest
    {
        public string Tipo { get; set; } // "credito" ou "debito"
        public decimal Valor { get; set; }
    }
}