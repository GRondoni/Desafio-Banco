namespace BancoApi.Application.DTOs
{
    public class SaldoResponse
    {
        public decimal Saldo { get; set; }
    }
}