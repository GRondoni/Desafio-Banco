using System.Data;
using System.Threading;
using System.Threading.Tasks;
using BancoApi.Application.Commands;
using Dapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BancoApi.Application.Handlers
{
    public class MovimentarContaHandler : IRequestHandler<MovimentarContaCommand, IActionResult>
    {
        private readonly IDbConnection _dbConnection;

        public MovimentarContaHandler(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<IActionResult> Handle(MovimentarContaCommand request, CancellationToken cancellationToken)
        {
            if (request.Valor <= 0)
                return new BadRequestObjectResult(new { erro = "Valor inválido", tipo = "valor_invalido" });

            if (request.TipoMovimento != "C" && request.TipoMovimento != "D")
                return new BadRequestObjectResult(new { erro = "Tipo de movimento inválido", tipo = "tipo_invalido" });

            var conta = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT * FROM ContaCorrente WHERE Id = @Id AND Ativa = 1",
                new { Id = request.IdContaCorrente });

            if (conta == null)
                return new BadRequestObjectResult(new { erro = "Conta inexistente ou inativa", tipo = "conta_invalida" });

            var existente = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT Id FROM Movimento WHERE ChaveIdempotencia = @ChaveIdempotencia AND IdContaCorrente = @IdContaCorrente",
                new { request.ChaveIdempotencia, request.IdContaCorrente });

            if (existente != null)
                return new OkObjectResult(new { id = existente.Id, status = "movimento_existente" });

            var sql = @"
                INSERT INTO Movimento (IdContaCorrente, Tipo, Valor, ChaveIdempotencia, DataCriacao)
                VALUES (@IdContaCorrente, @Tipo, @Valor, @ChaveIdempotencia, CURRENT_TIMESTAMP);
                SELECT last_insert_rowid();";

            var novoId = await _dbConnection.ExecuteScalarAsync<long>(sql, new
            {
                IdContaCorrente = request.IdContaCorrente,
                Tipo = request.TipoMovimento,
                Valor = request.Valor,
                ChaveIdempotencia = request.ChaveIdempotencia
            });

            return new OkObjectResult(new { id = novoId });
        }
    }
}