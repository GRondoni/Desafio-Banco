using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BancoApi.Application.Queries;
using Dapper;
using MediatR;

namespace BancoApi.Application.Handlers
{
    public class ObterSaldoHandler : IRequestHandler<ObterSaldoQuery, object>
    {
        private readonly IDbConnection _dbConnection;

        public ObterSaldoHandler(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task<object> Handle(ObterSaldoQuery request, CancellationToken cancellationToken)
        {
            var conta = await _dbConnection.QueryFirstOrDefaultAsync<dynamic>(
                "SELECT * FROM ContaCorrente WHERE Id = @Id",
                new { Id = request.IdContaCorrente });

            if (conta == null)
                return new { erro = "Conta inexistente", tipo = "conta_invalida" };

            var movimentos = await _dbConnection.QueryAsync<dynamic>(
                "SELECT Tipo, Valor FROM Movimento WHERE IdContaCorrente = @Id",
                new { Id = request.IdContaCorrente });

            decimal saldo = 0;
            foreach (var mov in movimentos)
            {
                if (mov.Tipo == "C")
                    saldo += (decimal)mov.Valor;
                else if (mov.Tipo == "D")
                    saldo -= (decimal)mov.Valor;
            }

            return new
            {
                idContaCorrente = request.IdContaCorrente,
                saldo
            };
        }
    }
}