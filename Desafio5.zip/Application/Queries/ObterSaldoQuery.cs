using MediatR;

namespace BancoApi.Application.Queries
{
    public class ObterSaldoQuery : IRequest<object>
    {
        public string IdContaCorrente { get; set; }
    }
}