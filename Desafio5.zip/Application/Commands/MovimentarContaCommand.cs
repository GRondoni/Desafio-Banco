using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace BancoApi.Application.Commands
{
    public class MovimentarContaCommand : IRequest<IActionResult>
    {
        public string IdContaCorrente { get; set; }
        public string ChaveIdempotencia { get; set; }
        public string TipoMovimento { get; set; }
        public decimal Valor { get; set; }
    }
}